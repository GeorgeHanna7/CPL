'''
------George Hanna, Marcus Butok, and Ryan Eaton
------CS 4308, Section: W02
------Kennesaw State University
------Dr. Jose Garrido
------02/24/20
------ Concepts of Programming Languages
'''

from Scanner import *

myScanner = Scanner('sclex1')
results = open('results.txt', 'w')

print("Filename:", myScanner.getFileName())
print("Number of lines in code:", myScanner.getNumLines())
print("READ THE FILE:\n")

while myScanner.hasNextLine():
    myScanner.readNextLine()
    print ("LINE #", myScanner.getLineNum(), "-", myScanner.getLine().strip())
    print ("Tokens", myScanner.tokenizeLine())
    print  "myScanner.tokenizeCurrentLine(myScanner.getCurrentLine()"
    print
    "========="

    results.write(
        ("\nLINE # " + str(myScanner.getLineNum()) + " - " + myScanner.getLine().strip()))
    results.write(("\n" + myScanner.tokenizeLine(myScanner.getLine())))
    results.write("\n=============\n")
results.close()