'''
------George Hanna, Marcus Butok, and Ryan Eaton
------CS 4308, Section: W02
------Kennesaw State University
------Dr. Jose Garrido
------02/24/20
------ Concepts of Programming Languages
'''


import re

class Token:

    def __init__(self, word, tokenType, value):
        self.word = word
        self.tokenType = tokenType
        self.value = value

    def toStr(self):
        return ("Token: " + self.word + ", " + self.tokenType + ", " + str(self.value))