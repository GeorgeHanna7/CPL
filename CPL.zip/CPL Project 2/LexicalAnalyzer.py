'''
------George Hanna, Marcus Butok, and Ryan Eaton
------CS 4308, Section: W02
------Kennesaw State University
------Dr. Jose Garrido
------02/24/20
------ Concepts of Programming Languages
'''


import re
from Token import *

lexicalAnalyzer = {
    "keywords": {
        'LET': 101,
        'PRINT': 102,
        'END': 103,
        'IF': 104,
        'FOR': 105,
        'COMPUTE': 106
    },

    "mathOps": {
        '+': 200,
        '-': 201,
        '*': 202,
        '/': 203,
        '>=': 204,
        '<=': 205,
        '==': 206,
        '!=': 207
    },

    "tokens": {
        '\\(': 300,  # open parenthesis
        '\\)': 301,  # close parenthesis
        '\"': 302,  # double quote
        '\[([a-zA-Z]|([\-]?[0-9]?.[0-9]))+\]': 303,  # brackets containing words/numbers
        '[\-]?[0-9]': 304,  # all numbers, including negative numbers
        '\[\]': 308,  # empty brackets
        '\,': 309,  # comma
        '\s+': 310,  # whitespace
        '[a-zA-Z]+': 311  # alpha word
    }

}


def tokenize(word):
    numericalValue = 0

    if word in lexicalAnalyzer["keywords"]:
        newToken = Token(word, "keyword", lexicalAnalyzer["keywords"][word])
        return newToken

    if word in lexicalAnalyzer["mathOps"]:
        newToken = Token(word, "math operator", lexicalAnalyzer["mathOps"][word])
        return newToken

    for subkey in lexicalAnalyzer["tokens"].keys():
        if re.match(subkey, word):
            numericalValue = lexicalAnalyzer["tokens"][subkey]

    if numericalValue == 0:
        return "No match found."
    newToken = Token(word, "token", numericalValue)
    return newToken
