'''
------George Hanna, Marcus Butok, and Ryan Eaton
------CS 4308, Section: W02
------Kennesaw State University
------Dr. Jose Garrido
------02/24/20
------ Concepts of Programming Languages
'''
from LexicalAnalyzer import *
from Token import *


class Scanner:

    def __init__(self, filename):
        self.filename = filename
        with open(filename, 'r') as f:
            self.fileObject = f.read().splitlines()
        self.numLines = len(self.fileObject)
        self.LineNum = 0
        self.Line = self.fileObject[self.LineNum]
        self.withinComment = False

    def getFileName(self):
        return self.filename

    def getNumLines(self):
        return self.numLines

    def getLine(self):
        return self.Line

    def getLineNum(self):
        return self.LineNum

    def getLineLength(self):
        return len(self.currentLine.split())

    def hasNextLine(self):
        return self.numLines - self.LineNum > 0

    def endFile(self):
        self.currentLineNum = self.numLines
        print("File is closed.")

    def tokenizeLine(self, line):
        tokenizedLine = ""
        for word in line.split():
            tokenizedLine += ("\n    " + tokenize(word).toStr())
        return (tokenizedLine)

    def readNextLine(self):
        if self.hasNextLine():
            self.Line = self.fileObject[self.LineNum]
            self.LineNum += 1
